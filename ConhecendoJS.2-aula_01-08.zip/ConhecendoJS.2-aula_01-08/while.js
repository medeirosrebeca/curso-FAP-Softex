//  /*1. Imprimir numeros de 1 a 10. */
//  let num = 1;
//  while (num < 11){
//      console.log(num);
//      num ++;
//  }
//  /*2. Calcular a soma dos numeros de 1 a 100. */
//  let numero = 1;
//  let soma = 0;
//  while (numero <=100){
//      soma += numero;
//      numero ++;
//  }
//      console.log(soma);
//  /*3. Contar e imprimir a quantidade de numeros pares de 1 a 50. */
//  let total = 1;
//  let par = 1;
//  while (total <=50){
//      if (par = total * 2){
//          console.log (par);
//          par++;
//      }
//      total ++;
//  }
// /*4. Multiplicar um numero por 2 ate que o resultado seja maior que 1000. */
//  let numeros = 1;
//  while (numeros <=1000){
//      numeros*= 2;
//          console.log(numeros);
//      }
/*5. Verificar se um numero é primo. */
let divisor = 2;
let numero = 23;
let primo = 29;

if (numero <= primo){
    primo ();
}
while (divisor < numero){
    if (numero % divisor === 0){
        console.log("O número não é primo");
    }
        divisor ++; 
} 
/*6. Faça o usuario digitar sua senha ate que seja digitada a senha correta.*/

/*7. Imprimir os multiplos de 3 de 1 a 30. */

/*8. Calcular a media de uma lista de numeros. */

/*9. Calcular o fatorial de um numero. */

/*10. Imprimir os numeros de 10 a 1 em ordem decrescente. */