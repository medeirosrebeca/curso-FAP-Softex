# Aula 01-08: Conhecendo Javascript 

* Estudo de << ARRAYS >>: São estruturas de dados que armazenam elementos.
  - Para acessar elemento, usar colchetes [].
  - Para alterar valor, atribuir indice e colocar novo valor.
  - Para adicionar novos indices, 'usar variavel.push()'.
  - Para remover item, usar 'delete' = variavel.lenght-1.
  - Para remover TUDO, usar 'array.splice()'.
  - Para calcular e exibir o tamanho do array: usar o '.length'.
  - Para adicionar elemento ao final do array: '.push'.
  - Para remover o primeiro elemento do array: '.shift'.
  - Para concatenar 2 arrays: '.concat'.
  - Para filtrar escolhas: '.filter()'.
  - Para ordenar o array em ordem crescente: '.sort()'.
  - Para encontrar o indice em que a variável esta localizada: 'constante.indexOf('variavel').
  - Para uma função que receba um parametro e verificar se é um array ou não. A função deve
retornar true ou false: console.log(Array.isArray('variavel'));


* Estudo de << DO WHILE >>: Garantir que uma ação seja realizada pelo menos uma vez, independentemente da condição inicial.

   
* Estudo de << WHILE >>: Cria um laço baseado em uma condição.
